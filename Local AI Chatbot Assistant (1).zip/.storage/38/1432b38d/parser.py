"""
Command parsing for Local AI Assistant
"""

import json
import re
from typing import Dict, Any, Optional, Tuple
from pydantic import BaseModel, Field

class ToolCall(BaseModel):
    """Represents a tool call request"""
    tool: str = Field(..., description="Name of the tool to call")
    args: Dict[str, Any] = Field(default_factory=dict, description="Arguments for the tool")
    needs_confirmation: bool = Field(default=False, description="Whether confirmation is needed")
    sensitivity: str = Field(default="low", description="Sensitivity level: low, medium, high")
    explain: str = Field(default="", description="Human-readable explanation")

class CommandParser:
    """Parses natural language commands into tool calls"""
    
    def __init__(self):
        self.patterns = self._init_patterns()
    
    def _init_patterns(self) -> Dict[str, Dict]:
        """Initialize command patterns for naive parsing"""
        return {
            "search_files": {
                "patterns": [
                    r"find\s+(.+?)\s+(?:in|under)\s+(.+)",
                    r"search\s+(?:for\s+)?(.+?)\s+(?:in|under)\s+(.+)",
                    r"locate\s+(.+?)\s+(?:in|under)\s+(.+)",
                    r"find\s+(.+)"
                ],
                "sensitivity": "low"
            },
            "read_text_file": {
                "patterns": [
                    r"read\s+(.+)",
                    r"open\s+(.+)",
                    r"show\s+(?:me\s+)?(?:the\s+)?(?:contents?\s+of\s+)?(.+)",
                    r"cat\s+(.+)"
                ],
                "sensitivity": "medium"
            },
            "list_processes": {
                "patterns": [
                    r"list\s+processes",
                    r"show\s+(?:running\s+)?processes",
                    r"ps\s*(?:aux)?",
                    r"what.*running"
                ],
                "sensitivity": "low"
            },
            "open_app": {
                "patterns": [
                    r"open\s+(.+?)\s*(?:app|application)?",
                    r"launch\s+(.+)",
                    r"start\s+(.+)",
                    r"run\s+(.+)"
                ],
                "sensitivity": "medium"
            },
            "read_webpage": {
                "patterns": [
                    r"read\s+(?:webpage?\s+)?(.+)",
                    r"fetch\s+(?:content\s+from\s+)?(.+)",
                    r"get\s+(?:text\s+from\s+)?(.+)"
                ],
                "sensitivity": "low"
            },
            "schedule_reminder": {
                "patterns": [
                    r"remind\s+me\s+(.+?)\s+(?:at|in)\s+(.+)",
                    r"schedule\s+(.+?)\s+(?:for|at)\s+(.+)",
                    r"set\s+(?:a\s+)?reminder\s+(.+?)\s+(?:for|at)\s+(.+)"
                ],
                "sensitivity": "low"
            },
            "request_elevation": {
                "patterns": [
                    r"(?:sudo\s+)?install\s+(.+)",
                    r"(?:sudo\s+)?apt\s+install\s+(.+)",
                    r"(?:sudo\s+)?yum\s+install\s+(.+)",
                    r"run\s+as\s+admin\s+(.+)",
                    r"elevate\s+(.+)"
                ],
                "sensitivity": "high"
            }
        }
    
    def parse_command(self, text: str) -> Optional[ToolCall]:
        """Parse natural language command into tool call"""
        text = text.strip().lower()
        
        # Try to parse as JSON first (for direct tool calls)
        if text.startswith('{') and text.endswith('}'):
            try:
                data = json.loads(text)
                return ToolCall(**data)
            except (json.JSONDecodeError, ValueError):
                pass
        
        # Try pattern matching
        for tool_name, tool_info in self.patterns.items():
            for pattern in tool_info["patterns"]:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    return self._create_tool_call(tool_name, match, tool_info, text)
        
        return None
    
    def _create_tool_call(self, tool_name: str, match: re.Match, tool_info: Dict, original_text: str) -> ToolCall:
        """Create tool call from pattern match"""
        args = {}
        sensitivity = tool_info["sensitivity"]
        needs_confirmation = sensitivity in ["medium", "high"]
        
        if tool_name == "search_files":
            if len(match.groups()) >= 2:
                args = {"query": match.group(1).strip(), "base": match.group(2).strip()}
            else:
                args = {"query": match.group(1).strip()}
        
        elif tool_name == "read_text_file":
            args = {"path": match.group(1).strip()}
        
        elif tool_name == "list_processes":
            args = {"limit": 20}
        
        elif tool_name == "open_app":
            args = {"name": match.group(1).strip()}
        
        elif tool_name == "read_webpage":
            url = match.group(1).strip()
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            args = {"url": url}
        
        elif tool_name == "schedule_reminder":
            args = {
                "text": match.group(1).strip(),
                "when": match.group(2).strip()
            }
        
        elif tool_name == "request_elevation":
            args = {"cmd": match.group(1).strip()}
            needs_confirmation = True
        
        return ToolCall(
            tool=tool_name,
            args=args,
            needs_confirmation=needs_confirmation,
            sensitivity=sensitivity,
            explain=f"Execute {tool_name} with: {args}"
        )
    
    def suggest_corrections(self, text: str) -> List[str]:
        """Suggest possible corrections for unrecognized commands"""
        suggestions = []
        text_lower = text.lower()
        
        if any(word in text_lower for word in ["find", "search", "locate"]):
            suggestions.append("Try: 'find filename.txt in /path/to/directory'")
        
        if any(word in text_lower for word in ["read", "open", "show", "cat"]):
            suggestions.append("Try: 'read /path/to/file.txt'")
        
        if any(word in text_lower for word in ["process", "running", "ps"]):
            suggestions.append("Try: 'list processes'")
        
        if any(word in text_lower for word in ["launch", "start", "run"]):
            suggestions.append("Try: 'open application_name'")
        
        if any(word in text_lower for word in ["remind", "schedule"]):
            suggestions.append("Try: 'remind me to call John at 3pm'")
        
        return suggestions