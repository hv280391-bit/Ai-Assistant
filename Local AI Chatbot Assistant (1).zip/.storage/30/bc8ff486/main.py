#!/usr/bin/env python3
"""
Local AI Assistant - Main Entry Point
A secure Python-based local AI chatbot assistant.
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from pathlib import Path
import sys
import os

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.assistant import LocalAssistant
from core.config import Config
from auth.manager import AuthManager
from utils.prompts import setup_wizard

console = Console()
app = typer.Typer()

@app.command()
def main(
    config_path: str = typer.Option("config.json", help="Path to configuration file"),
    setup: bool = typer.Option(False, help="Run setup wizard")
):
    """Start the Local AI Assistant"""
    
    # Display banner
    banner = Text("🤖 Local AI Assistant", style="bold blue")
    subtitle = Text("Secure system automation under human control", style="dim")
    console.print(Panel.fit(f"{banner}\n{subtitle}", border_style="blue"))
    
    try:
        # Load or create configuration
        config = Config(config_path)
        
        # Run setup wizard if needed or requested
        if setup or not config.is_configured():
            console.print("\n[yellow]Running first-time setup...[/yellow]")
            setup_wizard(config)
        
        # Initialize authentication
        auth_manager = AuthManager(config)
        
        # Authenticate user
        if not auth_manager.authenticate():
            console.print("[red]Authentication failed. Exiting.[/red]")
            return
        
        # Initialize and start assistant
        assistant = LocalAssistant(config, auth_manager)
        assistant.start_chat()
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Assistant stopped by user.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

@app.command()
def verify_audit():
    """Verify audit log integrity"""
    from audit.chain import AuditChain
    
    config = Config("config.json")
    chain = AuditChain(config.audit_log_path, config.audit_secret_key)
    
    if chain.verify_chain():
        console.print("[green]✓ Audit log integrity verified[/green]")
    else:
        console.print("[red]✗ Audit log integrity compromised![/red]")

if __name__ == "__main__":
    app()