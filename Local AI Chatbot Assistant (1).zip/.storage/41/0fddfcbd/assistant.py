"""
Main assistant logic for Local AI Assistant
"""

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.text import Text
import json
from typing import Optional

from core.parser import CommandParser
from tools.registry import ToolRegistry
from audit.logger import AuditLogger
from utils.security import SecurityValidator

console = Console()

class LocalAssistant:
    """Main assistant class"""
    
    def __init__(self, config, auth_manager):
        self.config = config
        self.auth_manager = auth_manager
        self.parser = CommandParser()
        self.tool_registry = ToolRegistry(config, auth_manager)
        self.audit_logger = AuditLogger(config.audit_log_path, config.get_audit_secret())
        self.security_validator = SecurityValidator(config, auth_manager)
        
    def start_chat(self):
        """Start the main chat loop"""
        console.print("\n[green]🤖 Local AI Assistant is ready![/green]")
        console.print("[dim]Type 'help' for commands, 'quit' to exit[/dim]\n")
        
        while True:
            try:
                # Get user input
                user_input = Prompt.ask("[bold blue]You[/bold blue]")
                
                if not user_input.strip():
                    continue
                    
                if user_input.lower() in ['quit', 'exit', 'bye']:
                    console.print("[yellow]Goodbye![/yellow]")
                    break
                    
                if user_input.lower() == 'help':
                    self._show_help()
                    continue
                
                # Process the command
                self._process_command(user_input)
                
            except KeyboardInterrupt:
                console.print("\n[yellow]Use 'quit' to exit properly.[/yellow]")
            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")
                self.audit_logger.log_error(str(e), self.auth_manager.current_user)
    
    def _process_command(self, user_input: str):
        """Process a user command"""
        # Parse the command
        tool_call = self.parser.parse_command(user_input)
        
        if not tool_call:
            console.print("[yellow]I don't understand that command.[/yellow]")
            suggestions = self.parser.suggest_corrections(user_input)
            if suggestions:
                console.print("[dim]Try one of these:[/dim]")
                for suggestion in suggestions:
                    console.print(f"[dim]  • {suggestion}[/dim]")
            return
        
        # Validate security
        if not self.security_validator.validate_tool_call(tool_call):
            console.print("[red]Access denied: Insufficient permissions[/red]")
            return
        
        # Request confirmation if needed
        if tool_call.needs_confirmation:
            if not self._request_confirmation(tool_call):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        # Execute the tool
        try:
            result = self.tool_registry.execute_tool(tool_call.tool, tool_call.args)
            
            if result:
                console.print(f"[green]✓[/green] {result}")
            else:
                console.print("[yellow]Operation completed.[/yellow]")
                
            # Log the operation
            self.audit_logger.log_operation(
                tool_call.tool,
                tool_call.args,
                self.auth_manager.current_user,
                "success"
            )
            
        except Exception as e:
            console.print(f"[red]Error executing {tool_call.tool}: {e}[/red]")
            self.audit_logger.log_operation(
                tool_call.tool,
                tool_call.args,
                self.auth_manager.current_user,
                f"error: {e}"
            )
    
    def _request_confirmation(self, tool_call) -> bool:
        """Request user confirmation for sensitive operations"""
        console.print(Panel.fit(
            f"[yellow]Confirmation Required[/yellow]\n\n"
            f"Tool: {tool_call.tool}\n"
            f"Action: {tool_call.explain}\n"
            f"Sensitivity: {tool_call.sensitivity}",
            border_style="yellow"
        ))
        
        if tool_call.sensitivity == "high":
            # High sensitivity requires typing "I AUTHORIZE"
            response = Prompt.ask("[bold red]Type 'I AUTHORIZE' to continue[/bold red]")
            return response == "I AUTHORIZE"
        else:
            # Medium sensitivity requires y/n
            response = Prompt.ask("[yellow]Continue? (y/n)[/yellow]", default="n")
            return response.lower() in ['y', 'yes']
    
    def _show_help(self):
        """Show help information"""
        help_text = """
[bold blue]Local AI Assistant Commands[/bold blue]

[bold]File Operations:[/bold]
• find <filename> in <directory>  - Search for files
• read <filepath>                 - Read file contents

[bold]System Operations:[/bold]
• list processes                  - Show running processes
• open <app_name>                 - Launch application

[bold]Web Operations:[/bold]
• read webpage <url>              - Fetch webpage content

[bold]Scheduling:[/bold]
• remind me <task> at <time>      - Schedule reminder

[bold]Admin Operations:[/bold]
• install <package>               - Install software (admin only)

[bold]General:[/bold]
• help                           - Show this help
• quit                           - Exit assistant
        """
        console.print(Panel.fit(help_text, border_style="blue"))