"""
Authentication and authorization manager
"""

import hashlib
import getpass
from rich.console import Console
from rich.prompt import Prompt
from typing import Optional

console = Console()

class AuthManager:
    """Manages user authentication and authorization"""
    
    def __init__(self, config):
        self.config = config
        self.current_user: Optional[str] = None
        self.current_role: Optional[str] = None
    
    def authenticate(self) -> bool:
        """Authenticate user"""
        # If no users exist, create first user
        if not self.config.data["users"]:
            console.print("[yellow]No users found. Creating first user...[/yellow]")
            return self._create_first_user()
        
        # Login existing user
        return self._login_user()
    
    def _create_first_user(self) -> bool:
        """Create the first user account"""
        console.print("\n[bold blue]Create First User Account[/bold blue]")
        
        username = Prompt.ask("Username")
        if not username:
            console.print("[red]Username cannot be empty[/red]")
            return False
        
        password = getpass.getpass("Password: ")
        if not password:
            console.print("[red]Password cannot be empty[/red]")
            return False
        
        # Choose role
        console.print("\nAvailable roles:")
        console.print("1. viewer - Read-only access")
        console.print("2. operator - Can launch apps and perform operations")
        console.print("3. admin - Full access including system administration")
        
        role_choice = Prompt.ask("Choose role (1-3)", choices=["1", "2", "3"], default="2")
        role_map = {"1": "viewer", "2": "operator", "3": "admin"}
        role = role_map[role_choice]
        
        # Hash password
        password_hash = self._hash_password(password)
        
        # Save user
        self.config.add_user(username, password_hash, role)
        
        # Set current user
        self.current_user = username
        self.current_role = role
        
        console.print(f"[green]✓ User '{username}' created with role '{role}'[/green]")
        return True
    
    def _login_user(self) -> bool:
        """Login existing user"""
        console.print("\n[bold blue]Login[/bold blue]")
        
        username = Prompt.ask("Username")
        if not username:
            return False
        
        user_data = self.config.get_user(username)
        if not user_data:
            console.print("[red]User not found[/red]")
            return False
        
        password = getpass.getpass("Password: ")
        password_hash = self._hash_password(password)
        
        if password_hash != user_data["password_hash"]:
            console.print("[red]Invalid password[/red]")
            return False
        
        # Set current user
        self.current_user = username
        self.current_role = user_data["role"]
        
        console.print(f"[green]✓ Welcome back, {username}! ({self.current_role})[/green]")
        return True
    
    def _hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def has_permission(self, permission: str) -> bool:
        """Check if current user has specific permission"""
        if not self.current_role:
            return False
        
        role_permissions = self.config.get_role_permissions(self.current_role)
        return role_permissions.get(permission, False)
    
    def get_current_user(self) -> Optional[str]:
        """Get current username"""
        return self.current_user
    
    def get_current_role(self) -> Optional[str]:
        """Get current user role"""
        return self.current_role