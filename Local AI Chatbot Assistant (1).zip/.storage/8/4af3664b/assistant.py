"""
Main assistant logic for Local AI Assistant
"""

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.text import Text
from rich.table import Table
from typing import Dict, Any, Optional
import traceback

from .parser import CommandParser, ToolCall
from .config import Config
from auth.manager import AuthManager
from audit.logger import AuditLogger
from tools.registry import ToolRegistry
from utils.security import SecurityManager

console = Console()

class LocalAssistant:
    """Main assistant class"""
    
    def __init__(self, config: Config, auth_manager: AuthManager):
        self.config = config
        self.auth_manager = auth_manager
        self.parser = CommandParser()
        self.audit_logger = AuditLogger(config)
        self.tool_registry = ToolRegistry(config, auth_manager, self.audit_logger)
        self.security_manager = SecurityManager(config)
        
        # Log assistant startup
        self.audit_logger.log_event(
            "assistant_start",
            {"user": auth_manager.current_user, "role": auth_manager.current_role}
        )
    
    def start_chat(self):
        """Start interactive chat session"""
        user = self.auth_manager.current_user
        role = self.auth_manager.current_role
        
        welcome_text = Text()
        welcome_text.append("Welcome, ", style="dim")
        welcome_text.append(user, style="bold green")
        welcome_text.append(f" ({role})", style="dim")
        welcome_text.append("\nType 'help' for commands, 'quit' to exit", style="dim")
        
        console.print(Panel(welcome_text, title="🤖 Assistant Ready", border_style="green"))
        
        while True:
            try:
                # Get user input
                user_input = Prompt.ask("\n[bold blue]You[/bold blue]").strip()
                
                if not user_input:
                    continue
                
                # Handle special commands
                if user_input.lower() in ['quit', 'exit', 'bye']:
                    console.print("[yellow]Goodbye! 👋[/yellow]")
                    break
                
                if user_input.lower() == 'help':
                    self._show_help()
                    continue
                
                if user_input.lower() == 'status':
                    self._show_status()
                    continue
                
                # Process command
                self._process_command(user_input)
                
            except KeyboardInterrupt:
                console.print("\n[yellow]Use 'quit' to exit properly.[/yellow]")
            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")
                self.audit_logger.log_event("error", {"error": str(e), "traceback": traceback.format_exc()})
    
    def _process_command(self, user_input: str):
        """Process a user command"""
        # Log the request
        self.audit_logger.log_event("user_request", {"input": user_input})
        
        # Parse command
        tool_call = self.parser.parse_command(user_input)
        
        if not tool_call:
            console.print("[yellow]I don't understand that command.[/yellow]")
            suggestions = self.parser.suggest_corrections(user_input)
            if suggestions:
                console.print("\n[dim]Suggestions:[/dim]")
                for suggestion in suggestions:
                    console.print(f"  • {suggestion}")
            return
        
        # Check permissions
        if not self._check_permissions(tool_call):
            console.print(f"[red]Permission denied. Your role ({self.auth_manager.current_role}) cannot use {tool_call.tool}[/red]")
            return
        
        # Security validation
        if not self.security_manager.validate_tool_call(tool_call):
            console.print("[red]Security validation failed. Operation blocked.[/red]")
            return
        
        # Show what we're about to do
        self._show_tool_call_info(tool_call)
        
        # Request confirmation if needed
        if tool_call.needs_confirmation:
            if not self._get_confirmation(tool_call):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        # Execute tool
        try:
            result = self.tool_registry.execute_tool(tool_call)
            self._display_result(tool_call.tool, result)
            
        except Exception as e:
            console.print(f"[red]Tool execution failed: {e}[/red]")
            self.audit_logger.log_event("tool_error", {
                "tool": tool_call.tool,
                "error": str(e),
                "traceback": traceback.format_exc()
            })
    
    def _check_permissions(self, tool_call: ToolCall) -> bool:
        """Check if user has permission for tool"""
        role = self.auth_manager.current_role
        permissions = self.config.get_role_permissions(role)
        
        permission_map = {
            "search_files": "can_search_files",
            "read_text_file": "can_read_files",
            "list_processes": "can_list_processes",
            "open_app": "can_open_apps",
            "read_webpage": "can_read_web",
            "schedule_reminder": "can_schedule_reminders",
            "request_elevation": "can_elevate"
        }
        
        required_permission = permission_map.get(tool_call.tool)
        if not required_permission:
            return False
        
        return permissions.get(required_permission, False)
    
    def _show_tool_call_info(self, tool_call: ToolCall):
        """Display information about the tool call"""
        info_table = Table(show_header=False, box=None, padding=(0, 1))
        info_table.add_column("Key", style="dim")
        info_table.add_column("Value")
        
        info_table.add_row("Tool:", tool_call.tool)
        info_table.add_row("Sensitivity:", tool_call.sensitivity)
        if tool_call.explain:
            info_table.add_row("Action:", tool_call.explain)
        
        console.print(Panel(info_table, title="🔧 Tool Call", border_style="blue"))
    
    def _get_confirmation(self, tool_call: ToolCall) -> bool:
        """Get user confirmation for sensitive operations"""
        if tool_call.sensitivity == "high":
            # High sensitivity requires explicit authorization
            console.print(f"\n[red bold]HIGH SENSITIVITY OPERATION[/red bold]")
            console.print(f"Tool: {tool_call.tool}")
            console.print(f"Action: {tool_call.explain}")
            console.print("\n[yellow]Type 'I AUTHORIZE' to proceed:[/yellow]")
            
            response = Prompt.ask("Authorization").strip()
            return response == "I AUTHORIZE"
        
        elif tool_call.sensitivity == "medium":
            return Confirm.ask(f"\nProceed with {tool_call.tool}?", default=False)
        
        return True
    
    def _display_result(self, tool_name: str, result: Any):
        """Display tool execution result"""
        if isinstance(result, dict) and "error" in result:
            console.print(f"[red]Error: {result['error']}[/red]")
        elif isinstance(result, dict) and "success" in result:
            console.print(f"[green]✓ {result['success']}[/green]")
            if "data" in result:
                console.print(result["data"])
        else:
            console.print(result)
    
    def _show_help(self):
        """Show help information"""
        help_text = """
[bold]Available Commands:[/bold]

[dim]File Operations:[/dim]
• find <filename> in <directory>  - Search for files
• read <filepath>                 - Read text file contents

[dim]System Operations:[/dim]
• list processes                  - Show running processes
• open <app_name>                 - Launch application

[dim]Web Operations:[/dim]
• read webpage <url>              - Fetch webpage content

[dim]Scheduling:[/dim]
• remind me <text> at <time>      - Schedule reminder

[dim]System Commands:[/dim]
• help                           - Show this help
• status                         - Show current status
• quit                           - Exit assistant

[dim]Role Permissions:[/dim]
Your current role: [bold]{role}[/bold]
        """.format(role=self.auth_manager.current_role)
        
        console.print(Panel(help_text, title="📖 Help", border_style="blue"))
    
    def _show_status(self):
        """Show current status"""
        status_table = Table(show_header=False, box=None)
        status_table.add_column("Key", style="dim")
        status_table.add_column("Value")
        
        status_table.add_row("User:", self.auth_manager.current_user)
        status_table.add_row("Role:", self.auth_manager.current_role)
        status_table.add_row("Allowlisted Paths:", str(len(self.config.allowlisted_paths)))
        status_table.add_row("Whitelisted Apps:", str(len(self.config.whitelisted_apps)))
        
        console.print(Panel(status_table, title="📊 Status", border_style="green"))