"""
Authentication and authorization manager
"""

import hashlib
import getpass
from rich.console import Console
from rich.prompt import Prompt
from typing import Optional

from core.config import Config

console = Console()

class AuthManager:
    """Manages user authentication and authorization"""
    
    def __init__(self, config: Config):
        self.config = config
        self.current_user: Optional[str] = None
        self.current_role: Optional[str] = None
    
    def authenticate(self) -> bool:
        """Authenticate user"""
        console.print("\n[bold blue]🔐 Authentication Required[/bold blue]")
        
        # Get username
        username = Prompt.ask("Username")
        
        # Check if user exists
        user_data = self.config.get_user(username)
        if not user_data:
            console.print("[red]User not found.[/red]")
            
            # Offer to create new user if no users exist
            if not self.config.data["users"]:
                console.print("[yellow]No users configured. Let's create the first admin user.[/yellow]")
                return self._create_first_user(username)
            
            return False
        
        # Get password
        password = getpass.getpass("Password: ")
        password_hash = self._hash_password(password)
        
        # Verify password
        if password_hash != user_data["password_hash"]:
            console.print("[red]Invalid password.[/red]")
            return False
        
        # Set current user and role
        self.current_user = username
        self.current_role = user_data["role"]
        
        console.print(f"[green]✓ Authenticated as {username} ({self.current_role})[/green]")
        return True
    
    def _create_first_user(self, username: str) -> bool:
        """Create the first admin user"""
        console.print(f"\n[yellow]Creating admin user: {username}[/yellow]")
        
        # Get password
        password = getpass.getpass("Set password: ")
        confirm_password = getpass.getpass("Confirm password: ")
        
        if password != confirm_password:
            console.print("[red]Passwords don't match.[/red]")
            return False
        
        if len(password) < 8:
            console.print("[red]Password must be at least 8 characters.[/red]")
            return False
        
        # Create user
        password_hash = self._hash_password(password)
        self.config.add_user(username, password_hash, "admin")
        
        # Set current user
        self.current_user = username
        self.current_role = "admin"
        
        console.print(f"[green]✓ Admin user {username} created and authenticated[/green]")
        return True
    
    def _hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def has_permission(self, permission: str) -> bool:
        """Check if current user has specific permission"""
        if not self.current_role:
            return False
        
        permissions = self.config.get_role_permissions(self.current_role)
        return permissions.get(permission, False)
    
    def require_elevation(self) -> bool:
        """Check if user can perform elevated operations"""
        return self.has_permission("can_elevate")