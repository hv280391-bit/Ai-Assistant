"""
Configuration management for Local AI Assistant
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Any
from cryptography.fernet import Fernet
import keyring

class Config:
    """Configuration manager with secure storage"""
    
    def __init__(self, config_path: str = "config.json"):
        self.config_path = Path(config_path)
        self.data = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        if self.config_path.exists():
            with open(self.config_path, 'r') as f:
                return json.load(f)
        else:
            return self._default_config()
    
    def _default_config(self) -> Dict[str, Any]:
        """Create default configuration"""
        home_dir = str(Path.home())
        return {
            "version": "1.0.0",
            "configured": False,
            "allowlisted_paths": [
                home_dir,
                str(Path.cwd())
            ],
            "whitelisted_apps": [
                "notepad.exe" if os.name == 'nt' else "gedit",
                "calc.exe" if os.name == 'nt' else "gnome-calculator",
                "code",  # VS Code
                "firefox",
                "chrome"
            ],
            "audit_log_path": "audit.log",
            "max_file_size_mb": 10,
            "max_search_results": 100,
            "reminder_db_path": "reminders.db",
            "users": {},
            "roles": {
                "viewer": {
                    "can_read_files": True,
                    "can_search_files": True,
                    "can_list_processes": True,
                    "can_read_web": True,
                    "can_open_apps": False,
                    "can_schedule_reminders": True,
                    "can_elevate": False
                },
                "operator": {
                    "can_read_files": True,
                    "can_search_files": True,
                    "can_list_processes": True,
                    "can_read_web": True,
                    "can_open_apps": True,
                    "can_schedule_reminders": True,
                    "can_elevate": False
                },
                "admin": {
                    "can_read_files": True,
                    "can_search_files": True,
                    "can_list_processes": True,
                    "can_read_web": True,
                    "can_open_apps": True,
                    "can_schedule_reminders": True,
                    "can_elevate": True
                }
            }
        }
    
    def save(self):
        """Save configuration to file"""
        with open(self.config_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def is_configured(self) -> bool:
        """Check if initial setup is complete"""
        return self.data.get("configured", False)
    
    def mark_configured(self):
        """Mark configuration as complete"""
        self.data["configured"] = True
        self.save()
    
    @property
    def allowlisted_paths(self) -> List[str]:
        return self.data["allowlisted_paths"]
    
    @property
    def whitelisted_apps(self) -> List[str]:
        return self.data["whitelisted_apps"]
    
    @property
    def audit_log_path(self) -> str:
        return self.data["audit_log_path"]
    
    @property
    def audit_secret_key(self) -> bytes:
        """Get or create audit secret key from keyring"""
        key = keyring.get_password("local_assistant", "audit_key")
        if not key:
            key = Fernet.generate_key().decode()
            keyring.set_password("local_assistant", "audit_key", key)
        return key.encode()
    
    def get_user_role(self, username: str) -> str:
        """Get user role"""
        return self.data["users"].get(username, {}).get("role", "viewer")
    
    def get_role_permissions(self, role: str) -> Dict[str, bool]:
        """Get permissions for role"""
        return self.data["roles"].get(role, self.data["roles"]["viewer"])
    
    def add_user(self, username: str, password_hash: str, role: str):
        """Add user to configuration"""
        self.data["users"][username] = {
            "password_hash": password_hash,
            "role": role
        }
        self.save()
    
    def get_user(self, username: str) -> Dict[str, Any]:
        """Get user data"""
        return self.data["users"].get(username, {})